package com.example.vtwhaler.checkbookv2;

/**
 * Created by VTWhaler on 8/10/2017.
 */

public class Constants {
    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
    public static final String FOURTH_COLUMN="Fourth";

}
