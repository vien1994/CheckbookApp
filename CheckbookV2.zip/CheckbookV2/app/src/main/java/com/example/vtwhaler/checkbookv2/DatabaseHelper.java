package com.example.vtwhaler.checkbookv2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by VTWhaler on 8/10/2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String TABLE_NAME = "Expenses";
    private static final String expCOL1 = "ID";
    private static final String expCOL2 = "Category";
    private static final String expCOL3 = "AMOUNT";
    private static final String expCOL4 = "TAG";


    public DatabaseHelper(Context context) {
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + expCOL2 + " TEXT, " + expCOL3 + " REAL, " + expCOL4 + " TEXT);"; //Change COL3 to REAL AND ADDED A SEMICOLON AFTER )
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int j) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    public boolean addData(String category, double amount, String tag) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(expCOL2, category);
        contentValues.put(expCOL3, amount);
        contentValues.put(expCOL4, tag);

        Log.d(TAG, "addData: Adding " + category + ", " + tag + " and " + amount + " to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean deleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, null, null);
        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public Cursor getBills() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='bills'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getEntertainment() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='entertainment'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getFood() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='food'";
        Cursor data = db.rawQuery(query, null);
        return data;

    }

    public Cursor getGas() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='gas'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

}
