package com.example.vtwhaler.checkbookv2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.DecimalFormat;
import java.text.NumberFormat;

/**
 * Created by VTWhaler on 8/10/2017.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    private static final String TABLE_NAME = "Expenses";
    private static final String expCOL1 = "ID";
    private static final String expCOL2 = "Category";
    private static final String expCOL3 = "AMOUNT";
    private static final String expCOL4 = "TAG";

    private static final String TABLE_BALANCE= "Balance";
    private static final String balID = "ID";
    private static final String balAmount = "BalAmt";

    NumberFormat formatter = new DecimalFormat("#0.00");

    public DatabaseHelper(Context context) {
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                expCOL2 + " TEXT, " +
                expCOL3 + " REAL, " +
                expCOL4 + " TEXT);"; //Change COL3 to REAL AND ADDED A SEMICOLON AFTER )
        db.execSQL(createTable);
        String createBalance = "CREATE TABLE " + TABLE_BALANCE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                balAmount + " REAL);";
        db.execSQL(createBalance);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int j) {
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        db.execSQL("DROP IF TABLE EXISTS " + TABLE_BALANCE);
        onCreate(db);
    }

    public boolean addData(String category, double amount, String tag) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(expCOL2, category);
        contentValues.put(expCOL3, amount);
        contentValues.put(expCOL4, tag);

        Log.d(TAG, "addData: Adding " + category + ", " + tag + " and " + amount + " to " + TABLE_NAME);

        long result = db.insert(TABLE_NAME, null, contentValues);

        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public boolean emptyBal() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        if (data.getCount()==0) {
            return true;
        }
       return false;
    }

    public boolean initBal() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        double amt = 0;
        contentValues.put(balAmount, amt);

        long result = db.insert(TABLE_BALANCE, null, contentValues);
        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public String getBalDisplay() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + TABLE_BALANCE;
        Cursor data = db.rawQuery(query, null);
        data.moveToNext();
        String result = String.valueOf(formatter.format(data.getDouble(1)));


        return result;
    }

    public void addBal(int id, double amtToAdd) { //Try resolving this later.
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_BALANCE; //does it work?
        Cursor data = db.rawQuery(query, null);
        data.moveToNext();
        double dataVal = data.getDouble(1) + amtToAdd;
/*
        String stringID = Integer.toString(id);
        ContentValues contentValues = new ContentValues();
        contentValues.put(balID, id);
        contentValues.put(balAmount, dataVal);
        int result = db.update(TABLE_BALANCE, contentValues, "ID = ?", new String[] { stringID });

        return result;
*/

        String queryUpd = "UPDATE " + TABLE_BALANCE + " SET " + balAmount + " = '" + dataVal + "'";
        db.execSQL(queryUpd);
    }

    public void resetBal() {
        SQLiteDatabase db = this.getWritableDatabase();

        double dataVal = 0;
        String queryUpd = "UPDATE " + TABLE_BALANCE + " SET " + balAmount + " = '" + dataVal + "'";
        db.execSQL(queryUpd);
    }


    public boolean deleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, null, null);
        if (result == -1) {
            return false;
        }
        else {
            return true;
        }
    }

    public Cursor getBills() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='bills'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME;
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getEntertainment() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='entertainment'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor getFood() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='food'";
        Cursor data = db.rawQuery(query, null);
        return data;

    }

    public Cursor getGas() {
        SQLiteDatabase db = this.getWritableDatabase();

        String query = "SELECT * FROM " + TABLE_NAME + " WHERE lower(" + expCOL2 + ")='gas'";
        Cursor data = db.rawQuery(query, null);
        return data;
    }

}
