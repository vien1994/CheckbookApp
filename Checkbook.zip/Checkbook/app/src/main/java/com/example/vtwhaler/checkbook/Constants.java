package com.example.vtwhaler.checkbook;

/**
 * Created by VTWhaler on 8/2/2017.
 */

public class Constants {
    public static final String FIRST_COLUMN="First";
    public static final String SECOND_COLUMN="Second";
    public static final String THIRD_COLUMN="Third";
}
