package com.example.vtwhaler.checkbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    DatabaseHelper mDatabaseHelper;
    private Button btnAdd, btnViewData, btnDeleteAll; //added DeleteAll button
    private EditText editTextAmt, editTextCat, editTextTag; //additionally declared editTextCat

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextAmt = (EditText) findViewById(R.id.editTextAmt);
        editTextCat = (EditText) findViewById(R.id.editTextCat); //additionally declared editTextCat here
        editTextTag = (EditText) findViewById(R.id.editTextTag); //
        btnAdd = (Button) findViewById(R.id.button_submit);
        btnViewData = (Button) findViewById(R.id.buttonView);
        btnDeleteAll = (Button) findViewById(R.id.button_deleteAll); //added this as well
        mDatabaseHelper = new DatabaseHelper(this);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String category = editTextCat.getText().toString(); //added this line
                String amtTemp = editTextAmt.getText().toString();
                try {
                    double amt = Double.parseDouble(amtTemp);

                    String tag = editTextTag.getText().toString();
                    if (editTextCat.length() != 0 && editTextTag.length() != 0) { //ADD VALIDATION
                        AddData(category, amt, tag);
                        editTextAmt.setText("");
                        editTextCat.setText(""); //additional line here
                        editTextTag.setText("");
                    }
                    else {
                        toastMessage("You must put something in the text field!");
                    }
                } catch (NumberFormatException c) {
                    toastMessage("You must put something in the text field!"); //error catch for when amt is blank
                }
            }
        });

        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });

        btnDeleteAll.setOnClickListener(new View.OnClickListener() { //This section is new
            @Override
            public void onClick(View v) {
                deleteData();
            }
        });

    }

    public void deleteData() {
        boolean delete = mDatabaseHelper.deleteAllData();
        if (delete) {
            toastMessage("All Data Successfully Deleted!");
        }
        else {
            toastMessage("Oops! Something went wrong");
        }
    }

    public void AddData(String category, double amount, String tag) { //added a second parameter
        boolean insertData = mDatabaseHelper.addData(category, amount, tag); //second input added
        if (insertData) {
            toastMessage("Data Successfully Inserted!");
        }
        else {
            toastMessage("Something went wrong");
        }
    }

    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
