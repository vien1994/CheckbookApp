package com.example.vtwhaler.checkbook;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    DatabaseHelper mDatabaseHelper;
    private Button btnAdd, btnViewData;
    private EditText editTextAmt, editTextCat; //additionally declared editTextCat

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editTextAmt = (EditText) findViewById(R.id.editTextAmt);
        editTextCat = (EditText) findViewById(R.id.editTextCat); //additionally declared editTextCat here
        btnAdd = (Button) findViewById(R.id.button_submit);
        btnViewData = (Button) findViewById(R.id.buttonView);
        mDatabaseHelper = new DatabaseHelper(this);

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newEntry = editTextCat.getText().toString(); //added this line
                String newEntry2 = editTextAmt.getText().toString();
                //Double newEntry = Double.
                if(editTextAmt.length() != 0 && editTextCat.length() != 0) { //changed condition to include editTextCat
                    AddData(newEntry, newEntry2);
                    editTextAmt.setText("");
                    editTextCat.setText(""); //additional line here
                }
                else {
                    toastMessage("You must put something in the text field!");
                }
            }
        });

        btnViewData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListDataActivity.class);
                startActivity(intent);
            }
        });

    }

    public void AddData(String newEntry, String newEntry2) { //added a second parameter
        boolean insertData = mDatabaseHelper.addData(newEntry, newEntry2); //second input added
        if (insertData) {
            toastMessage("Data Successfully Inserted!");
        }
        else {
            toastMessage("Something went wrong");
        }
    }

    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
}
